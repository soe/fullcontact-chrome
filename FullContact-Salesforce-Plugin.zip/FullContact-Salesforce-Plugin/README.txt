## File structure

manifest.json - (definition file for this chrome extension)
background.html - (to access localstorage from the content script)
popup.html - (popup info page for this chrome extension + options page)
css (include stylesheets)
    -- main.css
images - include images
js (include javascript files)
    -- jquery.js
    -- main.js (autofill for edit pages, contact box for view pages)

